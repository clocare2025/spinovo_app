import 'package:flutter/material.dart';
import 'package:spinovo_app/widget/text_widget.dart';

class BookingScreen extends StatelessWidget {
  const BookingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SmallText(
        text: "Booking Screen",
      ),
    );
  }
}
