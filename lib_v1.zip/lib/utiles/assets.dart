

class AppAssets {
  static String logo = "asset/images/logo.png";
  static String wallet = "asset/icons/wallet.png";
  static String walletV2 = "asset/icons/wallet_v2.png";
  // Service
  static String ironing = "asset/images/ironing.png";
  static String drycleaning = "asset/images/drycleaning.png";
  static String wash = "asset/images/wash.png";
  static String washIroning = "asset/images/washironing.png";
  static String shoesCleaning = "asset/images/shoe_cleaning.png";
  static String offerIcon = "asset/icons/offer.png";
}